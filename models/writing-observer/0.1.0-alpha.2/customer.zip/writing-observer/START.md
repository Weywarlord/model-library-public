# 写作旁观者：开始使用（10万次私人自测卡）

这是一个**由作者选择方向**的写作旁观工具，不给作品打分，也不自动改写。需要本地 AI 能读取文件、运行 Python 3.12+ 并访问 HTTPS；现有授权客户端曾在 macOS 验收，写作包仍需真实端到端验收。只会在作者确认本次上传时发送所选中文片段到 Cloudflare。单次成功的新计算扣写作商品 1 次，安装和查余额不扣次。服务端为防重复扣次暂存带有原文短引文的结果；超过 24 小时的结果在该账户下一次查询或计算时清理，闲置账户的清理可能延后。

请先让 AI 阅读本目录的 `PROMPT.md`。AI 应说明需要读写哪些本地文件、将向 `https://api.ainative.us.ci` 发送草稿片段，以及本次扣次规则。顾客**不要把 CDKEY、访问凭证或 Secret 文件贴进聊天**。

## 首次购买与第二个模型

如果已用旧域名激活过任意模型，先运行 `python3 -B start.py migrate`，再执行下面的 setup。迁移只验证既有凭证后更新服务地址，不输入新 CDKEY、不扣次；失败时保留原配置。关系模型新版也提供 `customer_release/start.py migrate`。两个模型共用凭证，迁移一次即可。

在本目录运行：

```sh
python3 -B start.py setup
```

脚本先检查网络，再请顾客在终端隐藏输入 Payhip 邮件中的写作商品 CDKEY。若电脑已激活关系模型，脚本把这张卡兑换到同一个本地访问凭证；若这是第一张卡，就创建新凭证。Secret 仍在 `~/.relationship-compute/Secret`，只由脚本读写，AI 不应打开它。成功时看到 `status: active`、`model_id: writing_observer`、`limit: 100000`、`remaining: 100000`。若网络请求中断，先恢复同一命令的联网权限，沿用原 CDKEY 重试，不换码。

查写作余额：

```sh
python3 -B start.py status
```

使用修复后的关系模型包（4.2.0-alpha-r11及以后），可用其 `customer_release/start.py status` 查关系模型余额。旧关系包可能默认查询首次购买的商品；若先买写作，应安装新版关系包，保留原 Secret 和旧案例。两个商品独立计数，同一本地凭证可以兼有两种权益。

## 使用一次

先让 AI 问清写作目标、文体和希望读者获得的体验。把要讨论的中文片段保存为 UTF-8 文件，先由作者确认**上传这一段、成功后扣 1 次**，再运行：

```sh
python3 -B start.py compute --input '/草稿文件绝对路径.txt' --genre scene --confirmed
```

`genre` 可选 `scene`、`essay`、`instruction`、`other`。请求 JSON 上限 16 KiB，中文片段通常应少于约 2,000 字，过长请先选取一段。空白、太短和不支持的文本不会扣次。服务器只返回最多三条有原文依据的候选方向；AI 按 `PROMPT.md` 与作者讨论，作者可全部不采纳。

若计算网络中断，**保留原草稿文件，不修改其内容和文体**，重新执行同一命令。脚本在 Secret 目录保存请求编号和草稿摘要；重试沿用编号，避免重复扣次。若提示 `PENDING_WRITING_REQUEST_MISMATCH`，说明上一请求结果未确定，先恢复原文件或联系售后，不删除 pending 记录来强行新算。查询余额不会替代一次未确定结果的核对。

本自测商品 [Payhip 页面](https://payhip.com/b/0GZrg) 限售 1 份。退款和订单问题请带订单号与购买邮箱联系 `lppinco@gmail.com`，不要发送秘密文件或草稿。脚本运行完自动退出；进行中的操作可按 `Ctrl-C` 停止，但如请求已发送仍需按上面方法核对。
