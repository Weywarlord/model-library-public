"""写作模型顾客入口；只通过本机 Secret 的既有凭证调用授权服务。"""

from __future__ import annotations

import argparse
import getpass
import hashlib
import json
from pathlib import Path
import re
import sys
import uuid
import warnings

from customer import ClientError, Customer, read_private, write_private


ROOT = Path(__file__).resolve().parent
DEFAULT_SECRET = Path.home() / ".relationship-compute" / "Secret"


def config():
    data = json.loads((ROOT / "service.json").read_text(encoding="utf-8"))
    if (data.get("server") != "https://api.loopinco.qzz.io"
            or not isinstance(data.get("product"), str)
            or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", data["product"])):
        raise ClientError("SERVICE_CONFIGURATION_INVALID")
    return data


def setup(client: Customer, settings: dict):
    client.preflight(settings["server"])
    with warnings.catch_warnings():
        warnings.simplefilter("error", getpass.GetPassWarning)
        license_key = getpass.getpass("写作商品 CDKEY（输入隐藏）：").strip()
    if not 0 < len(license_key) <= 512:
        raise ClientError("LICENSE_FORMAT_INVALID")
    # A second model is always redeemed into the existing access token.
    if (client.directory / "access.json").exists():
        return client.redeem(settings["product"], license_key)
    return client.activate(settings["server"], settings["product"], license_key)


def compute(client: Customer, settings: dict, path: Path, genre: str):
    text = path.read_text(encoding="utf-8")
    if len(re.sub(r"\s", "", text)) < 40 or len(re.findall(r"[\u4e00-\u9fff]", text)) < 8:
        raise ClientError("DRAFT_TOO_SHORT_OR_LANGUAGE_UNSUPPORTED")
    if genre not in {"scene", "essay", "instruction", "other"}:
        raise ClientError("GENRE_INVALID")
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    pending = client.directory / "writing-pending.json"
    if pending.exists():
        record = read_private(pending)
        if (record.get("draft_sha256") != digest or record.get("genre") != genre
                or record.get("product") != settings["product"]
                or not isinstance(record.get("request_id"), str)):
            raise ClientError("PENDING_WRITING_REQUEST_MISMATCH")
        request_id = record["request_id"]
    else:
        request_id = str(uuid.uuid4())
    payload = {"request_id": request_id, "inputs_confirmed": True, "text": text, "genre": genre}
    # Match the exact serialization used by the shared customer HTTP client.
    if len(json.dumps(payload, allow_nan=False).encode("utf-8")) > 16_384:
        raise ClientError("DRAFT_EXCEEDS_16K_REQUEST_LIMIT")
    if not pending.exists():
        write_private(pending, {"request_id": request_id, "draft_sha256": digest,
                                "genre": genre, "product": settings["product"]})
    result = client.compute(payload, settings["product"])
    if result.get("status") != "ok" or result.get("request_id") != request_id:
        raise ClientError("COMPUTE_RESPONSE_INVALID")
    pending.unlink()
    return {"status": "ok", "request_id": request_id, "result": result.get("result"),
            "versions": result.get("versions")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["setup", "status", "compute"])
    parser.add_argument("--directory", type=Path, default=DEFAULT_SECRET)
    parser.add_argument("--input", type=Path, help="UTF-8 草稿文件，仅 compute 使用")
    parser.add_argument("--genre", choices=["scene", "essay", "instruction", "other"], default="other")
    parser.add_argument("--confirmed", action="store_true", help="确认本次上传草稿并扣 1 次成功计算")
    args = parser.parse_args()
    try:
        settings = config()
        client = Customer(args.directory)
        if args.action == "setup":
            result = setup(client, settings)
        elif args.action == "status":
            result = client.status(settings["product"])
        else:
            if args.input is None or not args.confirmed:
                raise ClientError("DRAFT_AND_CONFIRMATION_REQUIRED")
            result = compute(client, settings, args.input, args.genre)
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
        return 0
    except ClientError as exc:
        print(json.dumps({"status": "error", "code": str(exc)}, ensure_ascii=False))
    except (OSError, UnicodeError, json.JSONDecodeError):
        print('{"status":"error","code":"LOCAL_INPUT_OR_CONFIGURATION_INVALID"}')
    except KeyboardInterrupt:
        print('{"status":"error","code":"CANCELLED"}')
    return 1


if __name__ == "__main__":
    sys.exit(main())
