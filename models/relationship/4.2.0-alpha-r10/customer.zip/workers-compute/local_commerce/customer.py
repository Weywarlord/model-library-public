"""Standalone standard-library customer CLI. No MCP or merchant key required."""
import argparse
import getpass
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import stat
import sys
import urllib.error
import urllib.request
from urllib.parse import urlsplit
import warnings


class ClientError(Exception):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def private_directory(path):
    path = Path(path).absolute()
    for part in (path, *path.parents):
        if part.is_symlink():
            raise ClientError('SECRET_DIRECTORY_SYMLINK')
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    if stat.S_IMODE(path.stat().st_mode) != 0o700:
        os.chmod(path, 0o700)
    return path


def read_private(path):
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    with os.fdopen(fd) as f:
        info = os.fstat(f.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise ClientError('SECRET_FILE_UNSAFE')
        if os.name == 'posix' and info.st_mode & 0o077:
            raise ClientError('SECRET_FILE_PERMISSIONS')
        return json.load(f)


def write_private(path, value):
    if path.is_symlink():
        raise ClientError('SECRET_FILE_SYMLINK')
    temp = path.with_name('.' + path.name + '.' + secrets.token_hex(8))
    try:
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w') as f:
            json.dump(value, f)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, path)
        # Persist the rename before any activation request is sent.
        if os.name == 'posix':
            directory_fd = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
    finally:
        if temp.exists():
            temp.unlink()


class Customer:
    def __init__(self, directory, allow_local_http=False):
        self.directory = private_directory(directory)
        self.allow_local_http = allow_local_http
        self.opener = urllib.request.build_opener(NoRedirect)

    def endpoint(self, value):
        parts = urlsplit(value)
        local = (self.allow_local_http and parts.scheme == 'http' and
                 parts.hostname in ('127.0.0.1', 'localhost', '::1'))
        if (parts.scheme != 'https' and not local) or not parts.hostname or parts.username or parts.password or parts.query or parts.fragment or parts.path not in ('', '/'):
            raise ClientError('HTTPS_ORIGIN_REQUIRED')
        return value.rstrip('/')

    def preflight(self, server):
        """Check this Python process can reach the service before asking for a CDKEY."""
        request = urllib.request.Request(self.endpoint(server) + '/health',
            headers={'User-Agent': 'relationship-customer/1.0'})
        try:
            with self.opener.open(request, timeout=10) as response:
                raw = response.read(4097)
            if len(raw) > 4096 or json.loads(raw).get('status') != 'ok':
                raise ClientError('SERVICE_HEALTH_INVALID')
        except urllib.error.HTTPError as exc:
            status = exc.code
            exc.close()
            raise ClientError('SERVER_HTTP_' + str(status)) from None
        except (urllib.error.URLError, TimeoutError):
            raise ClientError('NETWORK_PERMISSION_OR_CONNECTION_REQUIRED') from None
        except (ValueError, AttributeError):
            raise ClientError('SERVICE_HEALTH_INVALID') from None

    def request(self, config, route, body, key, product=None):
        base = self.endpoint(config['server'])
        req = urllib.request.Request(base + route, data=json.dumps(body, allow_nan=False).encode(),
            headers={'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key,
                     'User-Agent': 'relationship-customer/1.0',
                     'X-Product-ID': product or config['product']}, method='POST')
        try:
            with self.opener.open(req, timeout=30) as response:
                raw = response.read(262145)
            if len(raw) > 262144:
                raise ClientError('RESPONSE_TOO_LARGE')
            result = json.loads(raw)
            if not isinstance(result, dict):
                raise ClientError('RESPONSE_INVALID')
            return result
        except urllib.error.HTTPError as exc:
            status = exc.code
            # Never echo arbitrary server text or credentials back to the model.
            exc.close()
            raise ClientError('SERVER_HTTP_' + str(status)) from None
        except (urllib.error.URLError, TimeoutError):
            raise ClientError('NETWORK_ERROR_RETRY_SAME_OPERATION') from None

    def activate(self, server, product, license_key):
        config = {'server': self.endpoint(server), 'product': product}
        if not isinstance(product, str) or not re.fullmatch('[A-Za-z0-9_-]{1,128}', product):
            raise ClientError('PRODUCT_INVALID')
        credentials = self.directory / 'access.json'
        pending = self.directory / 'activation-pending.json'
        if credentials.exists():
            existing = read_private(credentials)
            if any(existing[k] != config[k] for k in config):
                raise ClientError('EXISTING_CONFIGURATION_MISMATCH')
            result = self.status()
            if pending.exists():
                pending.unlink()
            return result
        # OS lock is released even after a killed process; pending state survives.
        # This initial customer package targets macOS/Linux clients.
        import fcntl
        lock = self.directory / 'activation.lock'
        fd = os.open(lock, os.O_WRONLY | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            os.close(fd)
            raise ClientError('ACTIVATION_IN_PROGRESS') from None
        try:
            if credentials.exists():
                existing = read_private(credentials)
                if any(existing[k] != config[k] for k in config):
                    raise ClientError('EXISTING_CONFIGURATION_MISMATCH')
                return self.status()
            if pending.exists():
                state = read_private(pending)
                if any(state[k] != config[k] for k in config):
                    raise ClientError('PENDING_CONFIGURATION_MISMATCH')
                if state.get('license_fingerprint') != hashlib.sha256(license_key.encode()).hexdigest():
                    raise ClientError('PENDING_LICENSE_MISMATCH')
            else:
                state = {**config, 'activation_secret': secrets.token_hex(32),
                         'license_fingerprint': hashlib.sha256(license_key.encode()).hexdigest()}
                write_private(pending, state)
            result = self.request(config, '/license/activate',
                                  {'activation_secret': state['activation_secret']}, license_key)
            token = result.get('access_token', '')
            if not isinstance(token, str) or not re.fullmatch(r'rca_[0-9a-f]{64}(?:_[0-9a-f]{64})?', token):
                raise ClientError('ACTIVATION_RESPONSE_INVALID')
            if (result.get('status') != 'active' or
                    type(result.get('limit')) is not int or result['limit'] < 0 or
                    type(result.get('remaining')) is not int or
                    not 0 <= result['remaining'] <= result['limit'] or
                    result.get('period') != 'purchase' or
                    'expires_at' not in result):
                raise ClientError('ACTIVATION_RESPONSE_INVALID')
            write_private(credentials, {**config, 'access_token': token})
            pending.unlink()
            # Activation already includes the balance. A second network request
            # could fail after the credential was safely stored and mislead the buyer.
            return {k: result[k] for k in ('status', 'expires_at', 'limit', 'remaining', 'period', 'model_id') if k in result}
        finally:
            os.close(fd)

    def redeem(self, product, license_key):
        if not isinstance(product, str) or not re.fullmatch('[A-Za-z0-9_-]{1,128}', product):
            raise ClientError('PRODUCT_INVALID')
        config = read_private(self.directory / 'access.json')
        result = self.request(config, '/license/redeem', {'license_key': license_key}, config['access_token'], product)
        return {k: result[k] for k in ('status', 'expires_at', 'limit', 'remaining', 'period', 'model_id') if k in result}

    def status(self, product=None):
        config = read_private(self.directory / 'access.json')
        if product is not None and not re.fullmatch('[A-Za-z0-9_-]{1,128}', product):
            raise ClientError('PRODUCT_INVALID')
        result = self.request(config, '/license/status', {}, config['access_token'], product)
        # Only allow known, non-secret fields in the user-visible activation/status result.
        return {k: result[k] for k in ('status', 'expires_at', 'limit', 'remaining', 'period', 'model_id') if k in result}

    def migrate_server(self, server):
        """Switch an existing credential only after the new endpoint accepts it."""
        config = read_private(self.directory / 'access.json')
        target = self.endpoint(server)
        candidate = {**config, 'server': target}
        result = self.request(candidate, '/license/status', {}, config['access_token'])
        if result.get('status') != 'active':
            raise ClientError('MIGRATION_STATUS_INVALID')
        if config['server'] != target:
            write_private(self.directory / 'access.json', candidate)
        return {k: result[k] for k in ('status', 'expires_at', 'limit', 'remaining', 'period', 'model_id') if k in result}

    def compute(self, payload, product=None):
        config = read_private(self.directory / 'access.json')
        if product is not None and not re.fullmatch('[A-Za-z0-9_-]{1,128}', product):
            raise ClientError('PRODUCT_INVALID')
        return self.request(config, '/v2/compute', payload, config['access_token'], product)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=Path.home()/'.relationship-compute/Secret')
    parser.add_argument('--allow-local-http', action='store_true', help='Local acceptance only')
    sub = parser.add_subparsers(dest='action', required=True)
    activation = sub.add_parser('activate')
    activation.add_argument('--server', required=True)
    activation.add_argument('--product', required=True)
    activation.add_argument('--license-stdin', action='store_true', help='Read code via stdin, never command arguments')
    redemption = sub.add_parser('redeem')
    redemption.add_argument('--product', required=True)
    redemption.add_argument('--license-stdin', action='store_true', help='Read code via stdin, never command arguments')
    status = sub.add_parser('status')
    status.add_argument('--product')
    migration = sub.add_parser('migrate-server')
    migration.add_argument('--server', required=True)
    calculation = sub.add_parser('compute')
    calculation.add_argument('--input', type=Path, required=True)
    calculation.add_argument('--product')
    args = parser.parse_args()
    try:
        client = Customer(args.directory, args.allow_local_http)
        if args.action in ('activate', 'redeem'):
            if args.action == 'activate' and (client.directory / 'access.json').exists():
                # Already activated: check the existing credential without asking for the CDKEY again.
                result = client.activate(args.server, args.product, '')
            else:
                if args.action == 'activate':
                    client.preflight(args.server)
                if args.license_stdin:
                    key = sys.stdin.readline(514).strip()
                else:
                    with warnings.catch_warnings():
                        warnings.simplefilter('error', getpass.GetPassWarning)
                        key = getpass.getpass('CDKEY（输入隐藏）：').strip()
                if not key or len(key) > 512:
                    raise ClientError('LICENSE_FORMAT_INVALID')
                result = client.activate(args.server, args.product, key) if args.action == 'activate' else client.redeem(args.product, key)
        elif args.action == 'status':
            result = client.status(args.product)
        elif args.action == 'migrate-server':
            result = client.migrate_server(args.server)
        else:
            result = client.compute(json.loads(args.input.read_text()), args.product)
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
        return 0
    except ClientError as exc:
        print(json.dumps({'status': 'error', 'code': str(exc)}))
    except KeyboardInterrupt:
        print('{"status":"error","code":"CANCELLED"}')
    except Exception:
        print('{"status":"error","code":"LOCAL_CONFIGURATION_OR_RESPONSE_INVALID"}')
    return 1


if __name__ == '__main__':
    raise SystemExit(main())
