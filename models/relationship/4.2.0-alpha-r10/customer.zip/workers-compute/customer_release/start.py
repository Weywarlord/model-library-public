"""Customer activation/status entry. Reads only published service configuration."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['activate', 'redeem', 'status', 'migrate', 'help'])
    parser.add_argument('--directory', type=Path, default=Path.home()/'.relationship-compute/Secret')
    parser.add_argument('--product', help='Purchased product ID for redeem or a product-specific status query')
    args = parser.parse_args()
    config = json.loads((ROOT/'customer_release/service.json').read_text())
    if args.action == 'help':
        print(json.dumps({'purchase_url': config['purchase_url'],
            'support_email': config['support_email'],
            'support_instructions': '通过原订单邮件或商品页面联系商户，提供订单号和购买邮箱。不要发送访问凭证或Secret文件。退款须商户人工审核。',
            'renewal': '新购买的CDKEY可用redeem追加到同一凭证；不同商品权益独立，尚无自动订阅续期。'}, ensure_ascii=False))
        return 0
    server = config.get('server')
    if config.get('release_status') != 'ready' or not isinstance(server, str) or urlsplit(server).scheme != 'https':
        print('本包为未上线预览版。请等待商户提供完成云端验收的正式包；现在不输入CDKEY。')
        return 1
    command = [sys.executable, '-B', str(ROOT/'local_commerce/customer.py'),
               '--directory', str(args.directory), 'migrate-server' if args.action == 'migrate' else args.action]
    if args.action == 'activate':
        command += ['--server', server, '--product', config['product']]
    elif args.action == 'redeem':
        command += ['--product', args.product or config['product']]
    elif args.action == 'status' and args.product:
        command += ['--product', args.product]
    elif args.action == 'migrate':
        command += ['--server', server]
    return subprocess.run(command).returncode


if __name__ == '__main__':
    raise SystemExit(main())
