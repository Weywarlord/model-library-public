"""Send a user-confirmed sparse request to the Worker; never log credentials."""
import argparse
import json
import os
from pathlib import Path
import sys
import urllib.error
import urllib.request
from urllib.parse import urlsplit
import uuid
import math
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
REQUEST_SCHEMA = json.loads((ROOT / 'schemas/v2/request.schema.json').read_text())
RESPONSE_SCHEMA = json.loads((ROOT / 'schemas/v2/response.schema.json').read_text())
VERSIONS = {name: REQUEST_SCHEMA['properties'][name + '_version']['const']
            for name in ('schema', 'model', 'prompt')}

def validate(payload):
    # Only validate the public contract; customer installations contain no engine.
    def finite(value):
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError('NON_FINITE_INPUT')
        if isinstance(value, dict):
            for item in value.values(): finite(item)
        elif isinstance(value, list):
            for item in value: finite(item)
    finite(payload)
    Draft202012Validator(REQUEST_SCHEMA).validate(payload)

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

def call(base_url, payload, key, timeout=30, product_id=None):
    parsed = urlsplit(base_url)
    if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ("", "/"):
        raise ValueError("BASE_URL_INVALID")
    if parsed.scheme != "https" and not (parsed.scheme == "http" and parsed.hostname == "127.0.0.1"):
        raise ValueError("HTTPS_REQUIRED")
    validate(payload)
    request = urllib.request.Request(base_url.rstrip("/") + "/v2/compute",
        data=json.dumps(payload, allow_nan=False).encode(), method="POST",
        headers={"Authorization": "Bearer " + key, "Content-Type": "application/json", "User-Agent": "relationship-sample/2"})
    if product_id:
        request.add_header("X-Product-ID", product_id)
    opener = urllib.request.build_opener(NoRedirect)
    try: response = opener.open(request, timeout=timeout)
    except urllib.error.HTTPError as exc: response = exc
    with response:
        body = response.read(65537)
        if len(body) > 65536: raise ValueError("RESPONSE_TOO_LARGE")
        result = json.loads(body)
        from jsonschema import Draft202012Validator
        Draft202012Validator(RESPONSE_SCHEMA).validate(result)
        if response.status != 200 or result["status"] != "ok":
            raise ValueError("WORKER_REQUEST_FAILED")
        if result["versions"] != VERSIONS or result["request_id"] != payload.get("request_id"):
            raise ValueError("RESPONSE_MISMATCH")
        return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--confirmed", action="store_true", help="Use only after the user confirms the case summary")
    parser.add_argument("--base-url", default="https://relationship-compute.jp1996.workers.dev")
    parser.add_argument("--key-file", type=Path, default=ROOT / ".compute-api-key")
    parser.add_argument("--product-id", help="Optional commerce product ID for the local trial")
    args = parser.parse_args()
    if not args.confirmed: parser.error("Confirm the case summary before using --confirmed")
    try:
        payload = json.loads(args.request.read_text())
        # Reject an explicitly supplied incompatible version before adding metadata.
        validate(payload)
        payload.setdefault("request_id", str(uuid.uuid4()))
        payload.update(schema_version=VERSIONS["schema"], model_version=VERSIONS["model"],
                       prompt_version=VERSIONS["prompt"], inputs_confirmed=True)
        key = os.environ.get("COMPUTE_API_KEY") or args.key_file.read_text().strip()
        if not key: raise ValueError("MISSING_CREDENTIAL")
        result = call(args.base_url, payload, key, product_id=args.product_id)
    except (OSError, ValueError):
        print("计算未完成：请核对输入、版本、凭证和连接；未生成替代分数。", file=sys.stderr)
        return 1
    except Exception:
        print("计算未完成：响应不符合契约。", file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    return 0

if __name__ == "__main__": raise SystemExit(main())
