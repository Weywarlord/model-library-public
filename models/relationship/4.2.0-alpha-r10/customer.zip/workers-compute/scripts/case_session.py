"""Versioned local case records; numerical computation stays in the Worker."""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import uuid
import urllib.error
import sys

from call_compute import ROOT, VERSIONS, RESPONSE_SCHEMA, call, validate
from jsonschema import Draft202012Validator
from jsonschema.exceptions import ValidationError

sys.path.insert(0, str(ROOT / 'local_commerce'))
from customer import Customer, ClientError, read_private


def failure_code(exc):
    """Expose only allowlisted categories, never raw exception text or credentials."""
    if isinstance(exc, PermissionError):
        return 'LOCAL_PERMISSION_DENIED'
    if isinstance(exc, (TimeoutError,)):
        return 'NETWORK_TIMEOUT'
    if isinstance(exc, urllib.error.URLError):
        return 'NETWORK_ERROR'
    if isinstance(exc, OSError):
        return 'LOCAL_IO_ERROR'
    if isinstance(exc, ValidationError):
        return 'SCHEMA_MISMATCH'
    if isinstance(exc, ClientError):
        if str(exc) in {'SERVER_HTTP_400', 'SERVER_HTTP_401', 'SERVER_HTTP_402', 'SERVER_HTTP_403',
                        'SERVER_HTTP_409', 'SERVER_HTTP_410', 'SERVER_HTTP_422', 'SERVER_HTTP_429',
                        'SERVER_HTTP_500', 'SERVER_HTTP_502', 'SERVER_HTTP_503',
                        'NETWORK_ERROR_RETRY_SAME_OPERATION'}:
            return str(exc)
        return 'PERSONAL_ACCESS_REQUEST_FAILED'
    if isinstance(exc, ValueError) and str(exc) in {
        'MISSING_CREDENTIAL', 'RESPONSE_MISMATCH', 'RESPONSE_HASH_MISMATCH',
        'SNAPSHOT_MISMATCH', 'STATE_MISMATCH', 'CONFIRMATION_MISMATCH', 'REQUEST_MISMATCH',
        'COMPUTE_CONFIRMED_LATEST_ONLY', 'CONFIRM_LATEST_DRAFT_ONLY',
        'CONFIDENCE_OUTSIDE_PROMPT_BANDS', 'WORKER_REQUEST_FAILED',
        'SOURCE_TEXT_REQUIRED', 'QUOTE_NOT_IN_SOURCE',
        'RECOVER_EXISTING_REQUEST_FIRST', 'RECOVERY_NOT_ALLOWED',
        'CREDENTIAL_BINDING_MISMATCH', 'RECOVERY_AUTHORIZATION_REQUIRED',
    }:
        return str(exc)
    return 'INVALID_RECORD_OR_OPERATION'


def now():
    return datetime.now(timezone.utc).isoformat()


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False).encode('utf-8')


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, value):
    """Atomic replace: a crash cannot leave a partially written JSON file."""
    fd, temporary = tempfile.mkstemp(prefix='.writing-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(encoded(value) + b'\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


@contextmanager
def locked(case, read_only=False):
    if not read_only:
        case.mkdir(parents=True, exist_ok=True)
    with (case / '.lock').open('r' if read_only else 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_SH if read_only else fcntl.LOCK_EX)
        yield


def check_draft(draft):
    required = {'summary', 'prototype', 'marriage_years', 'evidence'}
    if not isinstance(draft, dict) or not required <= draft.keys() or draft.keys() - required - {'excluded', 'source_text'}:
        raise ValueError('DRAFT_FIELDS_INVALID')
    if not isinstance(draft['summary'], str) or not draft['summary'].strip():
        raise ValueError('SUMMARY_REQUIRED')
    if not isinstance(draft['evidence'], dict):
        raise ValueError('EVIDENCE_INVALID')
    if 'source_text' in draft and (not isinstance(draft['source_text'], str) or not draft['source_text'].strip()):
        raise ValueError('SOURCE_TEXT_REQUIRED')
    evidence = {}
    for factor, item in draft['evidence'].items():
        if not isinstance(item, dict) or set(item) != {'score', 'confidence', 'quote', 'reason'}:
            raise ValueError('EVIDENCE_FIELDS_INVALID')
        if any(not isinstance(item[k], str) or not item[k].strip() for k in ('quote', 'reason')):
            raise ValueError('EVIDENCE_GROUNDING_REQUIRED')
        evidence[factor] = {k: item[k] for k in ('score', 'confidence')}
    if 'excluded' in draft and (not isinstance(draft['excluded'], list) or
                                any(not isinstance(x, str) for x in draft['excluded'])):
        raise ValueError('EXCLUDED_INVALID')
    payload = {k: draft[k] for k in ('prototype', 'marriage_years')}
    payload['evidence'] = evidence
    validate(payload)
    return payload


def load(case, revision=None):
    manifest = read(case / 'index.json')
    if manifest.get('format') != 1:
        raise ValueError('RECORD_FORMAT_INVALID')
    revision = revision or manifest['latest']
    if not isinstance(revision, str) or not re.fullmatch(r'r[0-9]{4,}', revision):
        raise ValueError('REVISION_INVALID')
    expected = manifest['revisions'][revision]
    folder = case / revision
    snapshot = read(folder / 'snapshot.json')
    if digest(snapshot) != expected or snapshot['revision'] != revision or snapshot['versions'] != VERSIONS:
        raise ValueError('SNAPSHOT_MISMATCH')
    check_draft(snapshot['draft'])
    state = read(folder / 'state.json')
    if state['snapshot_hash'] != expected or state['revision'] != revision:
        raise ValueError('STATE_MISMATCH')
    if state['status'] not in ('draft', 'confirmed', 'running', 'failed', 'succeeded'):
        raise ValueError('STATE_INVALID')
    if state['status'] != 'draft':
        confirmation = state.get('confirmation', {})
        if confirmation.get('snapshot_hash') != expected or not confirmation.get('text', '').strip():
            raise ValueError('CONFIRMATION_MISMATCH')
    return manifest, folder, snapshot, state


def expected_request(snapshot):
    payload = check_draft(snapshot['draft'])
    payload.update(request_id=snapshot['request_id'], inputs_confirmed=True,
                   schema_version=VERSIONS['schema'], model_version=VERSIONS['model'],
                   prompt_version=VERSIONS['prompt'])
    validate(payload)
    return payload


def verify_response(payload, result):
    Draft202012Validator(RESPONSE_SCHEMA).validate(result)
    if result['status'] != 'ok' or result['request_id'] != payload['request_id'] or result['versions'] != VERSIONS:
        raise ValueError('RESPONSE_MISMATCH')


def prepare(case, draft):
    check_draft(draft)
    source = draft.get('source_text')
    if not isinstance(source, str) or not source.strip():
        raise ValueError('SOURCE_TEXT_REQUIRED')
    if any(item['quote'] not in source for item in draft['evidence'].values()):
        raise ValueError('QUOTE_NOT_IN_SOURCE')
    # Enforce the existing Prompt's observation tiers for new drafts only.
    # Historical snapshots remain readable; their content hashes are unchanged.
    for item in draft['evidence'].values():
        value = item['confidence']
        if not (value == 0 or .4 <= value <= .6 or .8 <= value <= .9 or .95 <= value <= 1):
            raise ValueError('CONFIDENCE_OUTSIDE_PROMPT_BANDS')
    with locked(case):
        if (case / 'index.json').exists():
            manifest, _, previous, previous_state = load(case)
            if (previous_state.get('transport') == 'personal' and
                    previous_state['status'] in ('running', 'failed') and
                    check_draft(previous['draft']) == check_draft(draft)):
                raise ValueError('RECOVER_EXISTING_REQUEST_FIRST')
        else:
            # Old unbound records are evidence, not a trusted migration source.
            if any((case / x).exists() for x in ('summary.md', 'request.json', 'response.json', 'evidence-map.json')):
                raise ValueError('LEGACY_CASE_USE_NEW_DIRECTORY')
            manifest = {'format': 1, 'latest': None, 'revisions': {}}
        number = len(manifest['revisions']) + 1
        while (case / f'r{number:04d}').exists():
            number += 1
        revision = f'r{number:04d}'
        folder = case / revision
        folder.mkdir()
        snapshot = {'revision': revision, 'created_at': now(), 'request_id': str(uuid.uuid4()),
                    'versions': VERSIONS, 'draft': draft}
        fingerprint = digest(snapshot)
        write(folder / 'snapshot.json', snapshot)
        write(folder / 'state.json', {'revision': revision, 'snapshot_hash': fingerprint,
                                     'status': 'draft', 'updated_at': now()})
        manifest['revisions'][revision] = fingerprint
        manifest['latest'] = revision
        write(case / 'index.json', manifest)
    return status(case, revision)


def confirm(case, revision, text):
    if not text.strip():
        raise ValueError('CONFIRMATION_REQUIRED')
    with locked(case):
        manifest, folder, _, state = load(case, revision)
        if revision != manifest['latest'] or state['status'] != 'draft':
            raise ValueError('CONFIRM_LATEST_DRAFT_ONLY')
        state.update(status='confirmed', updated_at=now(), confirmation={
            'text': text, 'at': now(), 'snapshot_hash': state['snapshot_hash']})
        write(folder / 'state.json', state)
    return status(case, revision)


def personal_client(directory, allow_local_http=False):
    client = Customer(directory, allow_local_http=allow_local_http)
    config = read_private(client.directory / 'access.json')
    # Bind retries to the original account and origin without storing its token.
    binding = digest({k: config[k] for k in ('server', 'product', 'access_token')})
    return client, binding


def compute(case, revision, base_url=None, key_file=None, *, credentials_directory=None,
            allow_local_http=False, recovery_authorization=None):
    with locked(case):
        manifest, folder, snapshot, state = load(case, revision)
        recovering = recovery_authorization is not None
        if recovering:
            if not recovery_authorization.strip():
                raise ValueError('RECOVERY_AUTHORIZATION_REQUIRED')
            if (revision != manifest['latest'] or state['status'] not in ('running', 'failed') or
                    state.get('transport') != 'personal' or credentials_directory is None or
                    state.get('error') == 'SERVER_HTTP_410'):
                raise ValueError('RECOVERY_NOT_ALLOWED')
        elif revision != manifest['latest'] or state['status'] != 'confirmed':
            raise ValueError('COMPUTE_CONFIRMED_LATEST_ONLY')
        payload = expected_request(snapshot)
        client = None
        if credentials_directory is not None:
            client, binding = personal_client(credentials_directory, allow_local_http)
            if recovering and state.get('credential_binding') != binding:
                raise ValueError('CREDENTIAL_BINDING_MISMATCH')
            state.update(transport='personal', credential_binding=binding)
        if recovering:
            if read(folder / 'request.json') != payload or state.get('request_hash') != digest(payload):
                raise ValueError('REQUEST_MISMATCH')
            state.setdefault('recovery_authorizations', []).append({'text': recovery_authorization, 'at': now()})
        write(folder / 'request.json', payload)
        state.update(status='running', updated_at=now(), request_hash=digest(payload))
        write(folder / 'state.json', state)
        try:
            if client is not None:
                result = client.compute(payload)
            else:
                key = os.environ.get('COMPUTE_API_KEY') or key_file.read_text().strip()
                if not key:
                    raise ValueError('MISSING_CREDENTIAL')
                result = call(base_url, payload, key)
            verify_response(payload, result)
            write(folder / 'response.json', result)
            state.update(status='succeeded', response_hash=digest(result), updated_at=now())
            state.pop('error', None)
        except Exception as exc:
            # No credentials, response bodies, or substituted scores enter failure records.
            state.update(status='failed', error=failure_code(exc), updated_at=now())
        write(folder / 'state.json', state)
    return status(case, revision)


def status(case, revision=None):
    if not (case / 'index.json').exists():
        return {'status': 'legacy_unverified' if case.exists() else 'not_found',
                'message': '没有可验证的修订记录；不能把旧响应关联到当前事实。'}
    with locked(case, read_only=True):
        manifest, folder, snapshot, state = load(case, revision)
        output = {'status': state['status'], 'revision': snapshot['revision'],
                  'is_latest': manifest['latest'] == snapshot['revision'],
                  'summary': snapshot['draft']['summary'], 'draft': snapshot['draft'],
                  'confirmed': state['status'] != 'draft', 'versions': snapshot['versions']}
        if state['status'] in ('running', 'failed', 'succeeded'):
            payload = read(folder / 'request.json')
            if payload != expected_request(snapshot) or digest(payload) != state['request_hash']:
                raise ValueError('REQUEST_MISMATCH')
        if state['status'] == 'succeeded':
            result = read(folder / 'response.json')
            verify_response(payload, result)
            if digest(result) != state['response_hash']:
                raise ValueError('RESPONSE_HASH_MISMATCH')
            output['result'] = result
        elif state['status'] == 'failed':
            output['error_code'] = state.get('error', 'COMPUTE_FAILED')
            output['message'] = '本修订计算失败，没有有效新分数。旧修订结果不能代替本次结果。'
            output['retry_policy'] = {
                'can_recompute_this_revision': False,
                'requires_new_revision': True,
                'requires_user_retry_authorization': True,
                'steps': ['取得用户针对本次事实的明确重试授权',
                          '用已核对草稿 prepare 创建新修订',
                          '将本次重试授权 confirm 到新修订',
                          '仅 compute 新修订；不得重算失败的旧修订'],
            }
        elif state['status'] == 'running':
            output['message'] = '本次调用未记录完成；结果未知，禁止自动重发或沿用旧分数。'
        if state.get('transport') == 'personal' and state['status'] in ('running', 'failed'):
            output['retry_policy'] = {
                'can_recompute_this_revision': False,
                'requires_new_revision': False,
                'requires_user_retry_authorization': True,
                'recovery_command': 'recover',
                'can_recover_with_new_authorization': state.get('error') != 'SERVER_HTTP_410',
                'steps': ['取得用户针对本次请求的明确恢复授权',
                          '使用原凭证和 recover 恢复原修订，保留原 request_id 与数值',
                          '不得为相同事实新建请求来重试；服务器保留的结果只扣一次',
                          '若返回410结果已过期，联系人工核对，不自动发起新的付费计算'],
            }
            if state.get('error') == 'SERVER_HTTP_410':
                output['message'] = '服务端缓存结果已过期，不能恢复当前分数；请联系人工核对原请求，不自动发起新付费计算。'
                output['retry_policy']['steps'] = ['联系商户核对原请求，不自动重新计算或扣次']
        return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    for name in ('prepare', 'confirm', 'compute', 'recover', 'status'):
        command = commands.add_parser(name)
        command.add_argument('--case', type=Path, required=True)
        if name == 'prepare':
            command.add_argument('--draft', type=Path, required=True)
        else:
            command.add_argument('--revision', required=name != 'status')
        if name in ('confirm', 'recover'):
            command.add_argument('--confirmation-file', type=Path, required=True)
        if name in ('compute', 'recover'):
            command.add_argument('--base-url', default='https://relationship-compute.jp1996.workers.dev')
            command.add_argument('--key-file', type=Path, default=ROOT / '.compute-api-key')
            command.add_argument('--credentials-directory', type=Path, required=name == 'recover')
            command.add_argument('--allow-local-http', action='store_true', help='Local acceptance only')
    args = parser.parse_args()
    try:
        if args.command == 'prepare':
            output = prepare(args.case, read(args.draft))
        elif args.command == 'confirm':
            output = confirm(args.case, args.revision, args.confirmation_file.read_text(encoding='utf-8'))
        elif args.command in ('compute', 'recover'):
            output = compute(args.case, args.revision, args.base_url, args.key_file,
                credentials_directory=args.credentials_directory, allow_local_http=args.allow_local_http,
                recovery_authorization=args.confirmation_file.read_text(encoding='utf-8') if args.command == 'recover' else None)
        else:
            output = status(args.case, args.revision)
    except Exception as exc:
        output = {'status': 'invalid_record_or_action',
                  'error_code': failure_code(exc),
                  'message': '输入、记录或状态不匹配；未提供任何分数。请核对草稿、修订和确认。'}
    print(json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False))
    return 1 if output['status'] in ('failed', 'invalid_record_or_action', 'legacy_unverified', 'not_found') else 0


if __name__ == '__main__':
    raise SystemExit(main())
