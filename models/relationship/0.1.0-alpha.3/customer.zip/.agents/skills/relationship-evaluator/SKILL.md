---
name: relationship-evaluator
description: 使用本项目的 4.2 版情感预测模型，倾听关系困扰、提取观察事实、确认摘要后调用 Cloudflare Worker，并解释关系边界风险指数。用于运行评估或解释已有结果；不用于修改模型、审计代码或升级 4.3 算法。
---

# Language and customer-facing presentation

Use the customer's preferred language for questions, the fact-check card, explanations and reports. If it has not been specified, follow the language of their current request. English is the default language of the store and installation guide; it is not a claim that every language has been tested.

Read the full canonical constitution and the workflow below, even when they are written in Chinese. Translate presentation faithfully; do not change factor meanings, scoring directions, confidence bands, thresholds, marriage-years requirements or version strings. Chinese headings below name required sections; render their English equivalents for an English-speaking customer. Ask for clarification if a phrase or translated factor meaning is ambiguous; do not silently guess.

Preserve `source_text` and every `quote` in the language actually used by the customer. Do not replace them with translations: each quote must remain an exact substring of source_text. Explain the mapping in the customer's language. Distinguish observed behavior, the other person's explanation and verification status. Unverified explanations are important leads to investigate, not proven lies and not grounds to discard the observed behavior. Long-standing habits are not automatically new changes. “I have not noticed” does not mean the risk is confirmed absent.

Present the fact-check card before requesting a computation. Wait for the customer's explicit confirmation of this revision; corrections require a new revision and fresh confirmation. Never manufacture a customer's confirmation. Keep unknown factors unknown, retain relevant background outside numerical evidence when no factor directly applies, and do not send original text or translations to the relationship Worker.

Successful English reports must contain these six sections, in order:

1. **Facts and observations** — observed changes, explanations and important unknowns.
2. **Model interactions** — distinguish activated interactions from unactivated/default-dependent ones.
3. **Observed protective factors** — state insufficient information when applicable; never invent protection.
4. **Risk index and model stage** — display information coverage alongside the index, explain all diagnostic warnings, preserve stage codes without inventing undefined labels. The index and probability field are not a validated real-world probability of infidelity.
5. **Practical next steps** — evidence-based questions and verification directions for the known facts.
6. **Corrections and reassessment** — how to correct facts and confirm a revised calculation; a successful new calculation costs one credit.

Use actual Worker results only. Failed/running/draft revisions have no current successful score; any older successful result must be explicitly historical. Keep recovery requests on the original account and request ID, and obtain fresh recovery authorization as described below. Do not read credentials, activate automatically to demonstrate installation, pay, send refund emails or claim a refund was processed. A normal refund request is drafted for manual support at the configured email.

The following Chinese reference preserves the full canonical workflow and commands. It remains authoritative for business and numerical meanings; the language rule above changes presentation only.


# 关系模型 4.2 客户端入口

本 Skill 连接现有 Prompt 与 Python 调用脚本，运行环境是可读本地文件、可执行 Python 并访问 HTTPS 的 AI 客户端。

## 加载与版本

项目根目录是本 Skill 所在 `.agents` 的上一级；其中应有 `workers-compute` 文件夹。先定位当前项目的实际绝对路径，不使用开发者电脑路径；不要搜索或读取凭证内容。

开始评估前完整读取项目内 `workers-compute/constitution.md`，包含因子字典、证据置信度规则、看板模板与工程对齐附录。按这些业务规则执行；本入口只说明实际调用方法，不修改权重、评分和观察语义。

固定配套版本：Prompt `0.1-Alpha.1`、模型 `4.2.0-alpha`、Schema `2.0`、路由 `/v2/compute`。核对 Prompt 与 `workers-compute/schemas/v2/request.schema.json`；版本不匹配时说明不兼容并停止计算。不要混载 v1 归档或卡尔曼研究版本。

`/health` 只能探测服务连接，不能证明授权或计算成功。v2 版本以本次计算响应为准，调用函数已严格校验。

## 对话与确认

1. 先倾听，再按 Prompt 自然追问必要缺口；不要展示完整因子表。婚龄未知时追问，不用 0 代替未知。
2. 将事实映射为稀疏 evidence。每个已提交因子在宿主侧保留对应原文、score、confidence 及映射理由。遵守因子方向，尤其 M 和 G；不从无关事实补出未提及的动机。未回答是未知，不能把一组问题的部分否定扩写成全部否定（例如用户只说“没有易怒”，不能写成“没有易怒或回避”）。
   置信度沿用 Prompt 的分层区间：S1 确凿事实 0.95～1.00，S2 反常观察 0.80～0.90，S3 无具体事实的直觉 0.40～0.60，S0 未知 0；未知因子通常不提交。不要使用区间之间的值（如 0.75、0.93），不要为获得某个结果改变层级。prepare 会拒绝区间外的置信度；应根据原文规则修正草稿，不能绕过校验。
   新草稿必须保存相关的原始用户事实到 source_text；多轮更正可保留仍用于溯源的原文片段，但不记录无关聊天。prepare 会检查每个 quote 是 source_text 的逐字子串，缺原文或引文改写会拒绝；旧快照仍可读取。source_text 留在本地，不发送到 Worker。每个 quote 必须使用用户实际说过的原文片段，不能从自己写的摘要反向制造引文，也不能加入“明显”“频繁”等原文没有的程度词。
   有引文不等于映射成立：还要核对它是否直接涉及该因子描述的行为。低风险输入也需要对应证据；“没有提供某种风险的证据”应保持未知，不能编码成已观察到该风险不存在。例如“争执可以协商”可作为报告中的保护事实，但本身不能证明“没有长期言语羞辱”，不据此给 f36 赋低值。可保留无法直接量化的事实在 summary / excluded 中，不为每句话强行找一个因子。
   历史上受到示好与当时拒绝，是分别记录的暴露背景和边界行为；当前联系未知时，不能仅凭过去拒绝给当前 s3 赋低值。先确认时间及后续接触情况，缺少直接依据时保留为背景，不由文献或默认值补出当前事实。
   观察行为、当事人解释、核实状态必须分开：用户明确观察到的行为若直接符合因子字典描述，应保留该行为输入；不能因为当事人给出另一种解释、解释未核实或动机不明就删去行为本身。将解释原话及“未核实”写入summary或该项reason，不把解释当作已经消除异常的证据，也不把“未核实”当作已经证实说谎。
   时间范围单独标明：因子若明确列举习惯性行为，已观察到的长期习惯应按该因子保留，不能仅以“一直如此、不是新变化”为由排除；同时不得改写成近期新增异常。只有因子本身要求近期变化时，才按变化条件判断。准备草稿前逐条核对已观察行为与字典；排除理由不能与上述规则冲突。
   解释未核实属于需要明确呈现、推动查证的重点线索，不是可随意略去的争议。它本身不新增一个风险因子，不自动提高score或confidence；数值仍按原Prompt描述及证据规则填写。若后来有新证据证实解释虚假，逐字记录新依据、适用范围和时间，重新提取、确认后计算，不预先认定动机或关系结局。
   “没发现／没注意到某种变化”只说明观察范围，不直接等于确认该风险不存在。先追问实际状况；用户仍不清楚时保持未知，不据此赋低风险值。明确确认稳定的实际状况与仅未发现变化分别处理，保留用户原话及其确定程度。
3. 向用户呈现自然语言事实摘要，得到明确确认后才调用。确认针对这一版摘要；用户修正事实后，更新映射并重新确认。项目开发授权不等于某个真实案例已经确认。
4. 只编辑一份草稿 JSON，再使用下述 `case_session.py` 管理修订、确认和调用。不要手写或修改脚本管理的 index.json、snapshot.json、state.json、request.json、response.json，不再并行维护 summary.md 和 evidence-map.json。原文与解释留在宿主，只有数值请求发往 Worker。
5. 中断后继续时，先运行 `status --case ...`；以校验后的状态为准。仅 `status=succeeded` 且 `is_latest=true` 的 result 可作为当前结果。`failed`、`running`、`draft`、`confirmed`、`legacy_unverified` 或记录校验失败都没有可展示的当前新分数。不要因为目录里存在 response.json 就宣称最新计算已完成。4.2 不发送 prior_state。
   最新修订失败时，历史成功只能称为“历史修订结果”，不能称为“当前有效结果仍为旧版”。可以按用户需要列出历史分数，但必须明确它不适用于当前修订；不要将“最新未完成”与“当前有效旧分数”放在同一结论中。

## 实际调用

Prompt 中的 `evaluate_relationship_risk` 是能力名称，本安装通过案例管理脚本复用现有调用函数，没有注册同名 MCP 工具。不要只输出函数名就声称已经计算。

草稿包含 `source_text`（相关用户原文，逐字保存，不从摘要改写）、`summary`（要呈现给用户确认的事实摘要）、`prototype`、`marriage_years`、`evidence`；可选 `excluded` 是未采纳线索及理由的字符串列表。每项 evidence 包含数值 `score`、`confidence` 和字符串 `quote`、`reason`。两个数值均为 0～1。通常用 `NEUTRAL`，按 Prompt 处理其他原型。字段约束需要核对时读项目下的 `workers-compute/schemas/v2/request.schema.json`。草稿示意（真实案例须用本次事实替换）：

```json
{"source_text":"结婚五年，最近三个月几乎不聊天。","summary":"结婚五年，近期交流减少。","prototype":"NEUTRAL","marriage_years":5,"evidence":{"e1":{"score":0.68,"confidence":0.85,"quote":"最近三个月几乎不聊天","reason":"近期交流显著减少"}},"excluded":["尚未涉及的心理动机不编码"]}
```

- 只提交有依据的项，不补齐未观测项，不提前做置信度融合、婚龄修正或本地算分。
- 不提交派生 f32；有对应证据才提交 f321/f322。不发送原文、摘要、姓名或其他附加字段。
- 缺失一般项以及 N 项的默认值均交给 Worker；不要在客户端一律填 0.5。
- 不复用样例的 request_id，也不将样例事实混进真实案例。脚本从同一份草稿生成数值请求，添加版本、确认标记和 UUID。

工作目录及命令如下，占位路径替换为当前可写目录中的实际路径。第一次 `prepare` 后保存返回的修订号（例如 r0001），向用户呈现该修订的 summary 并等待确认。用户确认后，将其实际确认文字写入文本文件，再依次 confirm 和 compute。不要模拟用户确认，不把“prepare 成功”当作用户确认。

```sh
cd "/当前项目绝对路径/workers-compute"
.venv/bin/python -B scripts/case_session.py prepare --case "/实际案例目录" --draft "/草稿路径/draft.json"
# 此处等待用户确认；收到确认后才执行下面两条。
.venv/bin/python -B scripts/case_session.py confirm --case "/实际案例目录" --revision r0001 --confirmation-file "/确认文字路径/confirmation.txt"
.venv/bin/python -B scripts/case_session.py compute --case "/实际案例目录" --revision r0001 --credentials-directory "$HOME/.relationship-compute/Secret"
# 接续或解释结果时仅查询，不重复计算。
.venv/bin/python -B scripts/case_session.py status --case "/实际案例目录"
```

顾客安装与首次激活按项目 `workers-compute/customer_release/开始使用.md` 操作。激活脚本隐藏读取 CDKEY，之后由脚本从个人 Secret 目录读取访问凭证。AI 不读取、显示或复制秘密文件，不把凭证写入案例或命令参数；不需要商户密钥或 MCP。缺少凭证时先完成激活，不切换共享密钥或另一个账户绕过扣次。若依赖、权限或连接缺失，说明实际条件，不绕过宿主限制。

激活、`customer_release/start.py status`、兑换和计算都要由 Python 发起 HTTPS 请求；先检查当前宿主的网络限制。若网络受限，使用客户端提供的正常权限申请机制，给**实际要执行的 Python 命令**联网权限；逐命令授权的宿主需要分别授权 activate、status 与 compute。只给网页工具或 curl `/health` 授权并不会授权 Python 进程。activate 在读取 CDKEY 前会用同一 Python 进程检查连通性；`NETWORK_PERMISSION_OR_CONNECTION_REQUIRED` 表示尚未读取 CDKEY、尚未发起激活，应取得联网权限后重跑同一命令。若激活请求中断，保留 pending，用原 CDKEY 和原目录恢复，不能换记录重复领取。`status` 返回 `NETWORK_ERROR_RETRY_SAME_OPERATION` 时，先核对该命令的联网权限，再做只读重试；不要重复激活或发起计算。权限审核拒绝时停止，不能绕过；不要为了试权限反复创建失败修订。网络错误码本身不能证明服务端故障，根因未明时如实说明。

事实修正时修改草稿，再次 prepare 创建新修订（r0002 等），确认自动失效，旧版本保留。核对返回的摘要、映射数值后重新让用户确认；确认和计算必须明确使用本次修订号。失败或 running 后不静默重试，先读取 status.retry_policy。个人凭证模式下相同事实用 recover 恢复原请求，不能新建请求重试；用户明确授权后，把新授权写入文本文件再执行：

```sh
.venv/bin/python -B scripts/case_session.py recover --case "/实际案例目录" --revision r0001 --credentials-directory "$HOME/.relationship-compute/Secret" --confirmation-file "/本次恢复授权.txt"
```

recover 保持原数值、原请求编号和原账户。返回410意味着缓存结果过期，不能自动发起新的付费计算；交人工核对。更换账户不能用于恢复原请求。

脚本自动保存最终发送请求和完整响应，并校验版本、request_id、输入与响应摘要值。输出 `status=succeeded` 时，Worker 原始数据位于 `result`（其中 status=ok），用它出报告。失败状态不会携带 result，不能从历史文件补上。不要自行抄写响应数值到文件。

旧式无修订记录的案例会返回 legacy_unverified；只解释为无法验证关联，不自动迁移或承认旧响应。需要重新评估时，用已核对事实创建新案例目录并执行确认。

## 报告与纠偏

按 Prompt 看板顺序完整展示事实镜像、模型交互解释、已观察到的保护事实、指数与阶段、相处建议及纠偏通道。即使某一板块信息不足，也明确说明，不省略该板块或填入模板里的虚构事实。

每次成功报告使用下面六个小标题并逐项填入内容：**事实镜像、模型交互解释、保护事实、指数与阶段、相处建议、纠偏入口**。发送前核对六项齐全，尤其不能在解释数值后漏掉最后两项。相处建议针对本次已知事实；纠偏入口说明用户可纠正事实，修订后重新确认、重新计算。失败时不套用成功报告模板，只说明实际状态与下一步。

- 所有结果数值取自本次 Worker 响应。跳过值为 null 的风险等级及交互等级，不自行补 LOW/MEDIUM/Lv 标签。
- 展示 coverage / data_completeness 和全部 diagnostics.warnings 的含义；少量证据时说明多数输入依赖默认设定。
- TOP3 是模型返回的交互排序，按 activated 区分是否激活。涉及未观测因子的交互，只能解释为模型默认输入下的推演，不能把它写成用户已证实的事实。
- 没有保护事实时如实说明资料未涉及，不照抄模板中的共同育儿或经济约束。阶段是本次模型快照；指数及 probability 字段不当作已验证的现实出轨概率。
- 在事实镜像和相处建议中明确列出已观察异常、当事人的解释及哪些解释尚待核实，给出与本次线索对应的核实问题；不能因解释存在就淡化异常，也不称其已经被证实为谎言。核实出现新事实后走修订与确认流程，不直接在旧报告上加分。
- 用户纠正任何用于计算的事实时返回摘要确认步骤，保存新的修订及请求响应；不要在原结果上手改分数。

失败恢复报告必须以 status.retry_policy 为准。个人凭证使用上述 recover；历史开发模式可能要求新修订，以脚本返回的模式为准。两种模式均不能复用第一次确认冒充新恢复授权。只读接续时只说明步骤，不执行。凭证只用于计算和查询，不能直接退款；续购提供配置中的购买链接，退款或丢失凭证按售后说明由商户核实原订单，不能声称已付款、已发邮件或已退款。
