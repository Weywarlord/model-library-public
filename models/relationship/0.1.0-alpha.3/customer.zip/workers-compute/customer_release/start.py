"""Customer activation/status entry. Reads only published service configuration."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['setup', 'activate', 'redeem', 'status', 'migrate', 'help'])
    parser.add_argument('--directory', type=Path, default=Path.home()/'.relationship-compute/Secret')
    parser.add_argument('--product', help='Purchased product ID for redeem or a product-specific status query')
    args = parser.parse_args()
    config = json.loads((ROOT/'customer_release/service.json').read_text())
    if args.action == 'help':
        print(json.dumps({'purchase_url': config['purchase_url'],
            'support_email': config['support_email'],
            'support_instructions': 'Contact support using your order email or product page. Include your order number and purchase email, never credentials or Secret files. Refunds require manual merchant review.',
            'renewal': 'Use redeem with a newly purchased License key to add credits to the same local credential. Each product has separate credits; automatic subscription renewal is not available.'}, ensure_ascii=False))
        return 0
    server = config.get('server')
    if config.get('release_status') != 'ready' or not isinstance(server, str) or urlsplit(server).scheme != 'https':
        print('This preview package is not connected to a ready service. Wait for a verified release; do not enter a License key yet.')
        return 1
    action = 'setup' if args.action in ('setup', 'activate') else 'migrate-server' if args.action == 'migrate' else args.action
    command = [sys.executable, '-B', str(ROOT/'local_commerce/customer.py'),
               '--directory', str(args.directory), action]
    if args.action in ('setup', 'activate'):
        command += ['--server', server, '--product', config['product']]
    elif args.action == 'redeem':
        command += ['--product', args.product or config['product']]
    elif args.action == 'status':
        command += ['--product', args.product or config['product']]
    elif args.action == 'migrate':
        command += ['--server', server]
    return subprocess.run(command).returncode


if __name__ == '__main__':
    raise SystemExit(main())
